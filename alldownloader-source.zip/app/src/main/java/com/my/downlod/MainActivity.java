package com.my.downlod;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Button;
import android.widget.TextView;
import android.widget.EditText;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;
import android.view.View;
import android.webkit.WebViewClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class MainActivity extends AppCompatActivity {
	
	
	private String searchq = "";
	private String pre = "";
	private String current_url = "";
	private String package_name = "";
	private String your_version = "";
	private String latest_version = "";
	private HashMap<String, Object> map = new HashMap<>();
	
	private LinearLayout linear6;
	private LinearLayout linear7;
	private ProgressBar progressbar2;
	private LinearLayout linear10;
	private LinearLayout linear12;
	private Button button4;
	private LinearLayout linear11;
	private Button button2;
	private Button button5;
	private TextView textview8;
	private Button button3;
	private EditText edittext2;
	private TextView textview7;
	private Button textview6;
	private WebView webview1;
	private TextView textview1;
	private Button button7;
	private Button button6;
	
	private RequestNetwork net;
	private RequestNetwork.RequestListener _net_request_listener;
	private AlertDialog.Builder d;
	private Intent ma = new Intent();
	
	private OnCompleteListener message_onCompleteListener;
	private Intent b = new Intent();
	private Intent s = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		progressbar2 = (ProgressBar) findViewById(R.id.progressbar2);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		button4 = (Button) findViewById(R.id.button4);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		button2 = (Button) findViewById(R.id.button2);
		button5 = (Button) findViewById(R.id.button5);
		textview8 = (TextView) findViewById(R.id.textview8);
		button3 = (Button) findViewById(R.id.button3);
		edittext2 = (EditText) findViewById(R.id.edittext2);
		textview7 = (TextView) findViewById(R.id.textview7);
		textview6 = (Button) findViewById(R.id.textview6);
		webview1 = (WebView) findViewById(R.id.webview1);
		webview1.getSettings().setJavaScriptEnabled(true);
		webview1.getSettings().setSupportZoom(true);
		textview1 = (TextView) findViewById(R.id.textview1);
		button7 = (Button) findViewById(R.id.button7);
		button6 = (Button) findViewById(R.id.button6);
		net = new RequestNetwork(this);
		d = new AlertDialog.Builder(this);
		
		button4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				s.setClass(getApplicationContext(), AbotActivity.class);
				startActivity(s);
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "Coded by shajahan ubaid🕺\nsource cod used by https://ddownloader.com/\n");
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		textview6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				ma.setAction(Intent.ACTION_VIEW);
				ma.setData(Uri.parse("mailto:shajahanubaid2@gmail.com"));
				ma.putExtra("subject", "write your subject");
				startActivity(ma);
			}
		});
		
		webview1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				current_url = webview1.getUrl();
				
				
				progressbar2.setVisibility(View.VISIBLE);
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				progressbar2.setVisibility(View.INVISIBLE);
				current_url = webview1.getUrl();
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		textview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (searchq.contains(pre)) {
					webview1.loadUrl(searchq);
				}
				else {
					webview1.loadUrl(pre.concat(searchq));
				}
				webview1.setWebChromeClient(new WebChromeClient() {  @Override public void onProgressChanged(WebView view, int progress) {   progressbar2.setProgress(progress);   super.onProgressChanged(view, progress);  } });
				progressbar2.setVisibility(View.VISIBLE);
			}
		});
		
		button7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				webview1.loadUrl("https://github.com/shajahanubaid/All-downloader");
			}
		});
		
		button6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				b.setClass(getApplicationContext(), UseActivity.class);
				startActivity(b);
			}
		});
		
		_net_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _response = _param2;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		message_onCompleteListener = new OnCompleteListener<InstanceIdResult>() {
			@Override
			public void onComplete(Task<InstanceIdResult> task) {
				final boolean _success = task.isSuccessful();
				final String _token = task.getResult().getToken();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
	}
	private void initializeLogic() {
		
		
		
		android.graphics.drawable.GradientDrawable mc = new android.graphics.drawable.GradientDrawable();
		mc.setColor(Color.parseColor("#FFFFFF"));
		mc.setCornerRadius(40);
		edittext2.setBackground(mc);
		android.graphics.drawable.GradientDrawable kb= new android.graphics.drawable.GradientDrawable();
		kb.setColor(Color.parseColor("#673AB7"));
		kb.setCornerRadius(40);
		linear7.setBackground(kb);
		android.graphics.drawable.GradientDrawable ok = new android.graphics.drawable.GradientDrawable();
		ok.setColor(Color.parseColor("#000000"));
		ok.setCornerRadius(40);
		textview7.setBackground(ok);
		pre = "https://ddownloader.com/";
		webview1.loadUrl("https://ddownloader.com/");
		webview1.setDownloadListener(new DownloadListener() {
			public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
				try {
					DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
					String cookies = CookieManager.getInstance().getCookie(url);
					request.addRequestHeader("cookie", cookies);
					request.addRequestHeader("User-Agent", userAgent);
					request.setDescription("Downloading file...");
					request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimetype));
					request.allowScanningByMediaScanner(); request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
					
					java.io.File aatv = new java.io.File(Environment.getExternalStorageDirectory().getPath() + "/Download");
					if(!aatv.exists()){if (!aatv.mkdirs()){ Log.e("TravellerLog ::","Problem creating Image folder");}}
					
					request.setDestinationInExternalPublicDir("/Download", URLUtil.guessFileName(url, contentDisposition, mimetype));
					
					DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
					manager.enqueue(request);
					showMessage("Downloading File....");
					
					//Notif if success
					BroadcastReceiver onComplete = new BroadcastReceiver() {
						public void onReceive(Context ctxt, Intent intent) {
							showMessage("Download Complete!");
							unregisterReceiver(this);
						}};
					registerReceiver(onComplete, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
				} catch (Exception e){
					showMessage(e.toString());
				}
			}
			
		});
		progressbar2.setVisibility(View.INVISIBLE);
		
		
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		if (webview1.canGoBack()) {
			webview1.goBack();
		}
		else {
			d.setTitle("All Downloder👇");
			d.setMessage("Are you sure you want to exit?🚶‍♂");
			d.setPositiveButton("YES", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					finish();
				}
			});
			d.setNegativeButton("NO", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					
				}
			});
			d.create().show();
		}
	}
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
